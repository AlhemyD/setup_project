# Ссылка на github

```https://github.com/AlhemyD/setup_project/tree/pypi_ready_tetsushiro```

# setup_project
В проекте представлена одна единственная функция add(x,y), которая складывает два числа (x,y) и возвращает их сумму.
# Установка

```pip install -e git+https://github.com/AlhemyD/setup_project.git#egg=setup_test_add```

или

```git clone https://github.com/AlhemyD/setup_project.git```

```cd setup_project```

```sudo python3 setup.py install```
