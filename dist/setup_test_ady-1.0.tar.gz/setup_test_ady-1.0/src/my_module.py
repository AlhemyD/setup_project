import numpy
def add(a, b):
    return a + b
